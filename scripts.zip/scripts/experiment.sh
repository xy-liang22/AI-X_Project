bash scripts/test_dragenfly_UGAL_UR.sh
bash scripts/test_dragenfly_UGAL_WC.sh
bash scripts/test_dragenfly_MIN_UR.sh
bash scripts/test_dragenfly_MIN_WC.sh
bash scripts/test_dragenfly_VAL_UR.sh
bash scripts/test_dragenfly_VAL_WC.sh
bash scripts/test_mesh.sh